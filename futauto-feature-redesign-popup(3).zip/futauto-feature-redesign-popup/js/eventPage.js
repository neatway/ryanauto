/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/eventPage.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/eventPage.ts":
/*!**************************!*\
  !*** ./src/eventPage.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Listen to messages sent from other parts of the extension.
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // onMessage must return "true" if response is async.
    var isResponseAsync = false;
    if (request.startAutobuyer) {
        chrome.storage.sync.set({ isRunning: true });
        chrome.browserAction.setBadgeBackgroundColor({ color: "#000000" });
        chrome.browserAction.setBadgeText({ text: "ON" });
        var resetPoint_1 = request.resetPoint, duration_1 = request.duration, action_1 = request.action, iterationTime_1 = request.iterationTime, iterationTimeMax_1 = request.iterationTimeMax, listStartPrice_1 = request.listStartPrice, listBinPrice_1 = request.listBinPrice, _a = request.isTestRun, isTestRun_1 = _a === void 0 ? false : _a, onInterval_1 = request.onInterval, offInterval_1 = request.offInterval, cycles_1 = request.cycles, maxBuyNowPrice_1 = request.maxBuyNowPrice, minimumCoinBalance_1 = request.minimumCoinBalance;
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                startAutobuyer: true,
                resetPoint: resetPoint_1,
                duration: duration_1,
                action: action_1,
                iterationTime: iterationTime_1,
                iterationTimeMax: iterationTimeMax_1,
                listStartPrice: listStartPrice_1,
                listBinPrice: listBinPrice_1,
                isTestRun: isTestRun_1,
                onInterval: onInterval_1,
                offInterval: offInterval_1,
                cycles: cycles_1,
                maxBuyNowPrice: maxBuyNowPrice_1,
                minimumCoinBalance: minimumCoinBalance_1,
            });
        });
    }
    else if (request.stopAutobuyer) {
        chrome.storage.sync.set({ isRunning: false });
        chrome.browserAction.setBadgeBackgroundColor({ color: "#000000" });
        chrome.browserAction.setBadgeText({ text: "OFF" });
    }
    else if (request.stopAutobuyerFromPopup) {
        chrome.storage.sync.set({ isRunning: false });
        chrome.browserAction.setBadgeBackgroundColor({ color: "#000000" });
        chrome.browserAction.setBadgeText({ text: "OFF" });
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                stopAutobuyerFromPopup: true,
            });
        });
    }
    else if (request.alert) {
        chrome.storage.sync.get(["discordId", "discordWebhook"], function (data) {
            if (data.discordId) {
                fetch_retry("https://shortfuts-server.herokuapp.com/alert/" + data.discordId, {
                    method: "POST",
                    body: JSON.stringify({ webhook: data.discordWebhook }),
                    headers: { "Content-Type": "application/json" },
                }, 5);
            }
        });
    }
    else if (request.getRunningStatus) {
        isResponseAsync = true;
        chrome.storage.sync.get(["isRunning"], function (data) {
            sendResponse({
                isRunning: data.isRunning,
            });
        });
    }
    else if (request.log) {
        var hasLogged = window.localStorage.getItem("hasReported");
        if (!hasLogged) {
            window.localStorage.setItem("hasReported", "true");
            chrome.identity.getProfileUserInfo(function (userInfo) {
                var email = userInfo.email;
                fetch("https://shortfuts-server.herokuapp.com/log/" + email, 
                // `http://localhost:3000/log/${email}`,
                {
                    method: "GET",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                    },
                    referrer: "no-referrer",
                });
            });
        }
    }
    return isResponseAsync;
});
var fetch_retry = function (url, options, n) {
    return fetch(url, options).catch(function (error) {
        if (n === 1)
            throw error;
        return fetch_retry(url, options, n - 1);
    });
};


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2V2ZW50UGFnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUNsRkEsNkRBQTZEO0FBQzdELE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWTtJQUNqRSxxREFBcUQ7SUFDckQsSUFBSSxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBRTVCLElBQUksT0FBTyxDQUFDLGNBQWMsRUFBRTtRQUMxQixNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUU3QyxNQUFNLENBQUMsYUFBYSxDQUFDLHVCQUF1QixDQUFDLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDbkUsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUdoRCxnQkFBVSxHQWFSLE9BQU8sV0FiQyxFQUNWLFVBQVEsR0FZTixPQUFPLFNBWkQsRUFDUixRQUFNLEdBV0osT0FBTyxPQVhILEVBQ04sZUFBYSxHQVVYLE9BQU8sY0FWSSxFQUNiLGtCQUFnQixHQVNkLE9BQU8saUJBVE8sRUFDaEIsZ0JBQWMsR0FRWixPQUFPLGVBUkssRUFDZCxjQUFZLEdBT1YsT0FBTyxhQVBHLEVBQ1osS0FNRSxPQUFPLFVBTlEsRUFBakIsV0FBUyxtQkFBRyxLQUFLLE9BQ2pCLFlBQVUsR0FLUixPQUFPLFdBTEMsRUFDVixhQUFXLEdBSVQsT0FBTyxZQUpFLEVBQ1gsUUFBTSxHQUdKLE9BQU8sT0FISCxFQUNOLGdCQUFjLEdBRVosT0FBTyxlQUZLLEVBQ2Qsb0JBQWtCLEdBQ2hCLE9BQU8sbUJBRFMsQ0FDUjtRQUVaLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLEVBQUUsVUFBVSxJQUFJO1lBQ3JFLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xDLGNBQWMsRUFBRSxJQUFJO2dCQUNwQixVQUFVLEVBQUUsWUFBVTtnQkFDdEIsUUFBUSxFQUFFLFVBQVE7Z0JBQ2xCLE1BQU0sRUFBRSxRQUFNO2dCQUNkLGFBQWEsRUFBRSxlQUFhO2dCQUM1QixnQkFBZ0IsRUFBRSxrQkFBZ0I7Z0JBQ2xDLGNBQWMsRUFBRSxnQkFBYztnQkFDOUIsWUFBWSxFQUFFLGNBQVk7Z0JBQzFCLFNBQVMsRUFBRSxXQUFTO2dCQUNwQixVQUFVO2dCQUNWLFdBQVc7Z0JBQ1gsTUFBTTtnQkFDTixjQUFjO2dCQUNkLGtCQUFrQjthQUNuQixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztLQUNKO1NBQU0sSUFBSSxPQUFPLENBQUMsYUFBYSxFQUFFO1FBQ2hDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBRTlDLE1BQU0sQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNuRSxNQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0tBQ3BEO1NBQU0sSUFBSSxPQUFPLENBQUMsc0JBQXNCLEVBQUU7UUFDekMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFFOUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLE1BQU0sQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFFbkQsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsRUFBRSxVQUFVLElBQUk7WUFDckUsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDbEMsc0JBQXNCLEVBQUUsSUFBSTthQUM3QixDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztLQUNKO1NBQU0sSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO1FBQ3hCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxFQUFFLFVBQUMsSUFBSTtZQUM1RCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLFdBQVcsQ0FDVCxrREFBZ0QsSUFBSSxDQUFDLFNBQVcsRUFDaEU7b0JBQ0UsTUFBTSxFQUFFLE1BQU07b0JBQ2QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN0RCxPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsa0JBQWtCLEVBQUU7aUJBQ2hELEVBQ0QsQ0FBQyxDQUNGLENBQUM7YUFDSDtRQUNILENBQUMsQ0FBQyxDQUFDO0tBQ0o7U0FBTSxJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtRQUNuQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBRXZCLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFLFVBQUMsSUFBSTtZQUMxQyxZQUFZLENBQUM7Z0JBQ1gsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2FBQzFCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0tBQ0o7U0FBTSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUU7UUFDdEIsSUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFN0QsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNkLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVuRCxNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFVBQUMsUUFBUTtnQkFDMUMsSUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztnQkFFN0IsS0FBSyxDQUNILGdEQUE4QyxLQUFPO2dCQUNyRCx3Q0FBd0M7Z0JBQ3hDO29CQUNFLE1BQU0sRUFBRSxLQUFLO29CQUNiLE9BQU8sRUFBRTt3QkFDUCxNQUFNLEVBQUUsa0JBQWtCO3dCQUMxQixjQUFjLEVBQUUsa0JBQWtCO3FCQUNuQztvQkFDRCxRQUFRLEVBQUUsYUFBYTtpQkFDeEIsQ0FDRixDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQUM7U0FDSjtLQUNGO0lBRUQsT0FBTyxlQUFlLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUM7QUFFSCxJQUFNLFdBQVcsR0FBRyxVQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQztJQUNsQyxZQUFLLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEtBQUs7UUFDdkMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUFFLE1BQU0sS0FBSyxDQUFDO1FBQ3pCLE9BQU8sV0FBVyxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzFDLENBQUMsQ0FBQztBQUhGLENBR0UsQ0FBQyIsImZpbGUiOiJldmVudFBhZ2UuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9ldmVudFBhZ2UudHNcIik7XG4iLCIvLyBMaXN0ZW4gdG8gbWVzc2FnZXMgc2VudCBmcm9tIG90aGVyIHBhcnRzIG9mIHRoZSBleHRlbnNpb24uXHJcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcclxuICAvLyBvbk1lc3NhZ2UgbXVzdCByZXR1cm4gXCJ0cnVlXCIgaWYgcmVzcG9uc2UgaXMgYXN5bmMuXHJcbiAgbGV0IGlzUmVzcG9uc2VBc3luYyA9IGZhbHNlO1xyXG5cclxuICBpZiAocmVxdWVzdC5zdGFydEF1dG9idXllcikge1xyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoeyBpc1J1bm5pbmc6IHRydWUgfSk7XHJcblxyXG4gICAgY2hyb21lLmJyb3dzZXJBY3Rpb24uc2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3IoeyBjb2xvcjogXCIjMDAwMDAwXCIgfSk7XHJcbiAgICBjaHJvbWUuYnJvd3NlckFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiBcIk9OXCIgfSk7XHJcblxyXG4gICAgY29uc3Qge1xyXG4gICAgICByZXNldFBvaW50LFxyXG4gICAgICBkdXJhdGlvbixcclxuICAgICAgYWN0aW9uLFxyXG4gICAgICBpdGVyYXRpb25UaW1lLFxyXG4gICAgICBpdGVyYXRpb25UaW1lTWF4LFxyXG4gICAgICBsaXN0U3RhcnRQcmljZSxcclxuICAgICAgbGlzdEJpblByaWNlLFxyXG4gICAgICBpc1Rlc3RSdW4gPSBmYWxzZSxcclxuICAgICAgb25JbnRlcnZhbCxcclxuICAgICAgb2ZmSW50ZXJ2YWwsXHJcbiAgICAgIGN5Y2xlcyxcclxuICAgICAgbWF4QnV5Tm93UHJpY2UsXHJcbiAgICAgIG1pbmltdW1Db2luQmFsYW5jZSxcclxuICAgIH0gPSByZXF1ZXN0O1xyXG5cclxuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sIGZ1bmN0aW9uICh0YWJzKSB7XHJcbiAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYnNbMF0uaWQsIHtcclxuICAgICAgICBzdGFydEF1dG9idXllcjogdHJ1ZSxcclxuICAgICAgICByZXNldFBvaW50OiByZXNldFBvaW50LFxyXG4gICAgICAgIGR1cmF0aW9uOiBkdXJhdGlvbixcclxuICAgICAgICBhY3Rpb246IGFjdGlvbixcclxuICAgICAgICBpdGVyYXRpb25UaW1lOiBpdGVyYXRpb25UaW1lLFxyXG4gICAgICAgIGl0ZXJhdGlvblRpbWVNYXg6IGl0ZXJhdGlvblRpbWVNYXgsXHJcbiAgICAgICAgbGlzdFN0YXJ0UHJpY2U6IGxpc3RTdGFydFByaWNlLFxyXG4gICAgICAgIGxpc3RCaW5QcmljZTogbGlzdEJpblByaWNlLFxyXG4gICAgICAgIGlzVGVzdFJ1bjogaXNUZXN0UnVuLFxyXG4gICAgICAgIG9uSW50ZXJ2YWwsXHJcbiAgICAgICAgb2ZmSW50ZXJ2YWwsXHJcbiAgICAgICAgY3ljbGVzLFxyXG4gICAgICAgIG1heEJ1eU5vd1ByaWNlLFxyXG4gICAgICAgIG1pbmltdW1Db2luQmFsYW5jZSxcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9IGVsc2UgaWYgKHJlcXVlc3Quc3RvcEF1dG9idXllcikge1xyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoeyBpc1J1bm5pbmc6IGZhbHNlIH0pO1xyXG5cclxuICAgIGNocm9tZS5icm93c2VyQWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6IFwiIzAwMDAwMFwiIH0pO1xyXG4gICAgY2hyb21lLmJyb3dzZXJBY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogXCJPRkZcIiB9KTtcclxuICB9IGVsc2UgaWYgKHJlcXVlc3Quc3RvcEF1dG9idXllckZyb21Qb3B1cCkge1xyXG4gICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5zZXQoeyBpc1J1bm5pbmc6IGZhbHNlIH0pO1xyXG5cclxuICAgIGNocm9tZS5icm93c2VyQWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6IFwiIzAwMDAwMFwiIH0pO1xyXG4gICAgY2hyb21lLmJyb3dzZXJBY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogXCJPRkZcIiB9KTtcclxuXHJcbiAgICBjaHJvbWUudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9LCBmdW5jdGlvbiAodGFicykge1xyXG4gICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJzWzBdLmlkLCB7XHJcbiAgICAgICAgc3RvcEF1dG9idXllckZyb21Qb3B1cDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9IGVsc2UgaWYgKHJlcXVlc3QuYWxlcnQpIHtcclxuICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KFtcImRpc2NvcmRJZFwiLCBcImRpc2NvcmRXZWJob29rXCJdLCAoZGF0YSkgPT4ge1xyXG4gICAgICBpZiAoZGF0YS5kaXNjb3JkSWQpIHtcclxuICAgICAgICBmZXRjaF9yZXRyeShcclxuICAgICAgICAgIGBodHRwczovL3Nob3J0ZnV0cy1zZXJ2ZXIuaGVyb2t1YXBwLmNvbS9hbGVydC8ke2RhdGEuZGlzY29yZElkfWAsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgd2ViaG9vazogZGF0YS5kaXNjb3JkV2ViaG9vayB9KSxcclxuICAgICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIDVcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9IGVsc2UgaWYgKHJlcXVlc3QuZ2V0UnVubmluZ1N0YXR1cykge1xyXG4gICAgaXNSZXNwb25zZUFzeW5jID0gdHJ1ZTtcclxuXHJcbiAgICBjaHJvbWUuc3RvcmFnZS5zeW5jLmdldChbXCJpc1J1bm5pbmdcIl0sIChkYXRhKSA9PiB7XHJcbiAgICAgIHNlbmRSZXNwb25zZSh7XHJcbiAgICAgICAgaXNSdW5uaW5nOiBkYXRhLmlzUnVubmluZyxcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxuICB9IGVsc2UgaWYgKHJlcXVlc3QubG9nKSB7XHJcbiAgICBjb25zdCBoYXNMb2dnZWQgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJoYXNSZXBvcnRlZFwiKTtcclxuXHJcbiAgICBpZiAoIWhhc0xvZ2dlZCkge1xyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJoYXNSZXBvcnRlZFwiLCBcInRydWVcIik7XHJcblxyXG4gICAgICBjaHJvbWUuaWRlbnRpdHkuZ2V0UHJvZmlsZVVzZXJJbmZvKCh1c2VySW5mbykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGVtYWlsID0gdXNlckluZm8uZW1haWw7XHJcblxyXG4gICAgICAgIGZldGNoKFxyXG4gICAgICAgICAgYGh0dHBzOi8vc2hvcnRmdXRzLXNlcnZlci5oZXJva3VhcHAuY29tL2xvZy8ke2VtYWlsfWAsXHJcbiAgICAgICAgICAvLyBgaHR0cDovL2xvY2FsaG9zdDozMDAwL2xvZy8ke2VtYWlsfWAsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG1ldGhvZDogXCJHRVRcIixcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHJlZmVycmVyOiBcIm5vLXJlZmVycmVyXCIsXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gaXNSZXNwb25zZUFzeW5jO1xyXG59KTtcclxuXHJcbmNvbnN0IGZldGNoX3JldHJ5ID0gKHVybCwgb3B0aW9ucywgbikgPT5cclxuICBmZXRjaCh1cmwsIG9wdGlvbnMpLmNhdGNoKGZ1bmN0aW9uIChlcnJvcikge1xyXG4gICAgaWYgKG4gPT09IDEpIHRocm93IGVycm9yO1xyXG4gICAgcmV0dXJuIGZldGNoX3JldHJ5KHVybCwgb3B0aW9ucywgbiAtIDEpO1xyXG4gIH0pO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9